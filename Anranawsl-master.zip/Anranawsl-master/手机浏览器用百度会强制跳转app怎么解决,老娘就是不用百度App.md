<div class="entry-content wow bounceInLeft animated" style="visibility: visible; animation-name: bounceInLeft;"> 

<div class="gutentoc tocactive nostyle"><div class="gutentoc-toc-wrap"><div class="gutentoc-toc-title-wrap"><div class="gutentoc-toc-title">目录</div><div id="open" class="toggletwo">hide</div></div><div id="toclist"><div class="gutentoc-toc__list-wrap"><ul class="gutentoc-toc__list"><li><a href="#背景介绍">背景介绍</a></li><li><a href="#方法一（最好用）">方法一（最好用）</a></li><li><a href="#方法二（x浏览器中操作）">方法二（x浏览器中操作）</a></li><li><a href="#方法三">方法三</a></li><li><a href="#方法四">方法四</a></li><li><a href="#方法五">方法五</a></li><li><a href="#有问题，联系我">有问题，联系我</a></li></ul></div></div></div></div>



<h1 id="背景介绍">背景介绍</h1>



<h4 id="当你在手机搜索内容的时候，会不会出现这样">当你在手机搜索内容的时候，会不会出现这样</h4>



<figure class="wp-block-image is-resized"><img loading="lazy" src="https://p.pstatp.com/origin/137940001dc81d2ec4ab1" alt="" width="352" height="563"></figure>



<h4 id="分明点了相关搜索">分明点了相关搜索</h4>



<figure class="wp-block-image"><img src="https://p.pstatp.com/origin/137760001c0dca05c7f91" alt=""></figure>



<h4 id="打开的还是这个，自己又打死不想下载百度app（因为各种非人性化的体验），还是喜欢即开即用的">打开的还是这个，自己又打死不想下载百度app（因为各种非人性化的体验），还是喜欢即开即用的</h4>



<div class="wp-block-image"><figure class="aligncenter is-resized"><img loading="lazy" src="https://p.pstatp.com/origin/fff30001f906d601613c" alt="" width="318" height="508"></figure></div>



<hr class="wp-block-separator">



<p></p>



<h1 id="方法一（最好用）">方法一（最好用）</h1>



<blockquote class="wp-block-quote"><p>为什么不用X浏览器了，因为使用“老娘就是不用百度app”插件后，X浏览器兼容性不好，当你点一个搜索标题的时候，会刷新一下页面，必须在点一次才行，Anran在尝试多款浏览器后，发现还是支持谷歌扩展程序的兼容性很好，而手机款只有Yandex和Kiwi两框，从响应速度上，Anran在这里推荐后者</p></blockquote>



<figure class="wp-block-pullquote"><blockquote><p><!--noindex--><noindex><a target="_blank" rel="nofollow" href="https://3kla.cn/blog/go/aHR0cDovL3Bhbi4za2xhLmNuL2Rpci8zMDM3ODIyMy00MTU2NDk3MS03ODQ3Nzg=">Kiwi浏览器下载</a></noindex><!--/noindex--></p><cite>包含Kiwi浏览器和油猴插件</cite></blockquote></figure>



<section rpeditro_index="0" rotate="0" scale="100" opacity="100" style="transform: rotate(0deg);opacity: 1;width: 100%;"><section><section data-type="lspecial02,lspecial06,lspecial01"><section style="margin-top:12px;"><section data-type="lspecial02,lspecial06,lspecial01" style="margin-top:-12px;"><section style="width:18px;height:18px;background-color:#000;border-radius:50%;"><section style="color:#fff;letter-spacing:1px;line-height:18px;text-align:center;"><p style="font-size:12px;padding:0px;margin:0px;">1<mpchecktext contenteditable="false" id="1606032984616_0.5622135484160851"></mpchecktext></p></section></section><section style="border-left:2px solid #000;padding:15px 15px 25px;margin-left:9px;box-sizing:border-box;"><section style="width:80%;"><p style="font-size:16px;padding:0px;margin:0px;">打开Kiwi，右上角点击选项，选择扩展程序<mpchecktext contenteditable="false" id="1606032984617_0.0799128305132244"></mpchecktext></p><p style="padding:0px;margin:0px;"><img data-cropselx1="0" data-cropselx2="407" data-cropsely1="0" data-cropsely2="269" data-ratio="1.7052023121387283" src="https://mmbiz.qpic.cn/mmbiz_png/uR4ibIuCrjiabMf89NiaOmgciaeCNUa8EC2P78XUapYib2mjPhjXt66eXXye5fLvhJCsOrP3tiayfxy7l8Vz92iaBKsIA/640?wx_fmt=png" data-type="png" data-w="346" style="width: 407px;vertical-align: middle;height: 694px;"></p></section></section></section><section data-type="lspecial02,lspecial06,lspecial01" style="margin-top:-12px;"><section style="width:18px;height:18px;background-color:#000;border-radius:50%;"><section style="color:#fff;letter-spacing:1px;line-height:18px;text-align:center;"><p style="font-size:12px;padding:0px;margin:0px;">2<mpchecktext contenteditable="false" id="1606032984618_0.9336134738279598"></mpchecktext></p></section></section><section style="border-left:2px solid #000;padding:15px 15px 25px;margin-left:9px;box-sizing:border-box;"><section style="width:80%;"><p style="font-size:16px;padding:0px;margin:0px;">打开开发者选项，点击load<mpchecktext contenteditable="false" id="1606032984619_0.32722337948681646"></mpchecktext></p><p style="padding:0px;margin:0px;"><img data-cropselx1="0" data-cropselx2="407" data-cropsely1="0" data-cropsely2="252" data-ratio="1.6822157434402332" src="https://mmbiz.qpic.cn/mmbiz_png/uR4ibIuCrjiabMf89NiaOmgciaeCNUa8EC2PXrk68loHJSdrLMUZhKKZMHLrVAN4Enya8jlXkkejSWPYPgBumQ3yjA/640?wx_fmt=png" data-type="png" data-w="343" style="width: 407px;vertical-align: middle;height: 685px;"></p></section></section></section><section data-type="lspecial02,lspecial06,lspecial01" style="margin-top:-12px;"><section style="width:18px;height:18px;background-color:#000;border-radius:50%;"><section style="color:#fff;letter-spacing:1px;line-height:18px;text-align:center;"><p style="font-size:12px;padding:0px;margin:0px;">3<mpchecktext contenteditable="false" id="1606032984620_0.5951032809049188"></mpchecktext></p></section></section><section style="border-left:2px solid #000;padding:15px 15px 25px;margin-left:9px;box-sizing:border-box;"><section style="width:80%;"><p style="font-size:16px;padding:0px;margin:0px;">用Kiwi下载的，在根目录下的Download里面，选择油猴并确认<mpchecktext contenteditable="false" id="1606032984621_0.042815179290893735"></mpchecktext></p><p style="padding:0px;margin:0px;"><img data-cropselx1="0" data-cropselx2="407" data-cropsely1="0" data-cropsely2="270" data-ratio="1.5603448275862069" src="https://mmbiz.qpic.cn/mmbiz_png/uR4ibIuCrjiabMf89NiaOmgciaeCNUa8EC2Pg6CIA6f1WLgqzKXkZmtibia0XSrHZgdiaY8oNVSHSs4RiafK9U2FwpJv2A/640?wx_fmt=png" data-type="png" data-w="348" style="width: 407px;vertical-align: middle;height: 635px;"></p></section></section></section><section data-type="lspecial02,lspecial06,lspecial01" style="margin-top:-12px;"><section style="width:18px;height:18px;background-color:#000;border-radius:50%;"><section style="color:#fff;letter-spacing:1px;line-height:18px;text-align:center;"><p style="font-size:12px;padding:0px;margin:0px;">4<mpchecktext contenteditable="false" id="1606032984622_0.6425410764359536"></mpchecktext></p></section></section><section style="border-left:2px solid #000;padding:15px 15px 25px;margin-left:9px;box-sizing:border-box;"><section style="width:80%;"><p style="font-size:16px;padding:0px;margin:0px;">开启油猴插件<mpchecktext contenteditable="false" id="1606032984623_0.273444164792219"></mpchecktext></p><p style="padding:0px;margin:0px;"><img data-cropselx1="0" data-cropselx2="407" data-cropsely1="0" data-cropsely2="271" data-ratio="1.6023688663282571" src="https://mmbiz.qpic.cn/mmbiz_png/uR4ibIuCrjiabMf89NiaOmgciaeCNUa8EC2PNrnLtMPialjg7Sq5ib6PiaCu4iaRxcwicBgPsbefoOUxFKGPPf1Pnu7CDiaA/640?wx_fmt=png" data-type="png" data-w="591" style="width: 407px;vertical-align: middle;height: 652px;"></p></section></section></section><section data-type="lspecial02,lspecial06,lspecial01" style="margin-top:-12px;"><section style="width:18px;height:18px;background-color:#000;border-radius:50%;"><section style="color:#fff;letter-spacing:1px;line-height:18px;text-align:center;"><p style="font-size:12px;padding:0px;margin:0px;">5<mpchecktext contenteditable="false" id="1606032984624_0.9722654943396423"></mpchecktext></p></section></section><section style="border-left:2px solid #000;padding:15px 15px 25px;margin-left:9px;box-sizing:border-box;"><section style="width:80%;"><p style="font-size:16px;padding:0px;margin:0px;">点开老娘不用百度app插件地址，安装即可,公众号回复：<mpchecktext contenteditable="false" id="1606032984625_0.4586429351762378"></mpchecktext>13<mpchecktext contenteditable="false" id="1606032984626_0.06759948877435029"></mpchecktext></p><p style="padding:0px;margin:0px;"><img data-cropselx1="0" data-cropselx2="407" data-cropsely1="0" data-cropsely2="271" data-ratio="1.6095076400679118" src="https://mmbiz.qpic.cn/mmbiz_png/uR4ibIuCrjiabMf89NiaOmgciaeCNUa8EC2PYDYz7CR8FnwuiahQAVPhs6JajC8SaRtIvwZiap1REW0xDb4icS3CSZkjw/640?wx_fmt=png" data-type="png" data-w="589" style="width: 407px;vertical-align: middle;height: 655px;"></p></section></section></section><section data-type="lspecial02,lspecial06,lspecial01" style="margin-top:-12px;"><section style="width:18px;height:18px;background-color:#000;border-radius:50%;"><section style="color:#fff;letter-spacing:1px;line-height:18px;text-align:center;"><p style="font-size:12px;padding:0px;margin:0px;">6</p></section></section><section style="border-left:2px solid #000;padding:15px 15px 25px;margin-left:9px;box-sizing:border-box;"><section style="width:80%;"><p style="font-size:16px;padding:0px;margin:0px;">打开m.baidu.com(手机版本的百度域名，即可获得简洁版的百度搜索结果)<mpchecktext contenteditable="false" id="1606032984633_0.07508595555833675"></mpchecktext><mpchecktext contenteditable="false" id="1606032984628_0.039668507814817344"></mpchecktext><br></p><p style="padding:0px;margin:0px;"><img data-cropselx1="0" data-cropselx2="407" data-cropsely1="0" data-cropsely2="271" data-ratio="1.6228668941979523" src="https://mmbiz.qpic.cn/mmbiz_png/uR4ibIuCrjiabMf89NiaOmgciaeCNUa8EC2P2GxYNsM0X5SBxKQSR1FX312dKaPzv5pBVKmuDeRhsF1MLud2rspNibg/640?wx_fmt=png" data-type="png" data-w="586" style="width: 407px;vertical-align: middle;height: 661px;"></p></section></section></section><section data-type="lspecial02,lspecial06,lspecial01" style="margin-top:-12px;"><section style="width:18px;height:18px;background-color:#000;border-radius:50%;"><section style="color:#fff;letter-spacing:1px;line-height:18px;text-align:center;"><p style="font-size:12px;padding:0px;margin:0px;">7<mpchecktext contenteditable="false" id="1606032984634_0.6705151955787232"></mpchecktext></p></section></section><section style="border-left:2px solid #000;padding:15px 15px 25px;margin-left:9px;box-sizing:border-box;"><section style="width:80%;"><p style="font-size:16px;padding:0px;margin:0px;">设置默认搜索，只要用m.baidu.com搜索了一次，就可以在设置-搜索引擎-中选择<mpchecktext contenteditable="false" id="1606032984661_0.12551319514636106"></mpchecktext><br></p><p style="padding:0px;margin:0px;"><img src="https://mmbiz.qlogo.cn/mmbiz_png/uR4ibIuCrjiabMf89NiaOmgciaeCNUa8EC2PduNda9rF0mic0dibK93SlxMG452CX5n2xe6u2n4SG4hLGHumcicwqJKmA/0?wx_fmt=png" class="" data-ratio="1.4101694915254237" width="407px" data-w="590" data-type="png">&#8203;</p></section></section></section></section></section></section><section><br></section></section>



<p></p>



<h1 id="方法二（x浏览器中操作）">方法二（x浏览器中操作）</h1>



<ol><li>首先需要有个<strong>自定义</strong>程度高的浏览器，例如X浏览器、Via浏览器的等。</li><li>这里以X浏览器为例，百度搜索后，点击右上角<br><img width="50%" src="https://p.pstatp.com/origin/137c30002ba09462c69b4"></li><li>对该网站禁用js（因为是通过这个js脚本<img src="https://p.pstatp.com/origin/1381d00029ecb0a32b3e3">进行的客户端判断、出现次数、构造跳转网址的）<img width="50%" src="https://p.pstatp.com/origin/1373d00021331327a5914"></li><li>最后返回刷新即可，<br><img width="50%" src="https://p.pstatp.com/origin/ffe40002ebebbff07c1c"></li><li>最后将会启用百度的<strong>【精简模式】</strong>重点是：广告、跳转都将统统消失，你的眼里只剩你想要的！！！</li></ol>



<h1 id="方法三">方法三</h1>



<h4 id="在出现使用百度app打开的时候">在出现使用百度app打开的时候</h4>



<p><img src="https://p.pstatp.com/origin/137760001c0dca05c7f91" width="50%"><br>比如选择的第一个，就长按第一个，弹出来选择后台打开，然后再点击该项目的时候，就不会跳转到百度app打开了</p>



<h1 id="方法四">方法四</h1>



<p>直接切换成电脑UA</p>



<h1 id="方法五">方法五</h1>



<p>切换成Wpa UA</p>



<h1 id="有问题，联系我">有问题，联系我</h1>



<div class="wp-block-image"><figure class="aligncenter is-resized"><img loading="lazy" src="https://p.pstatp.com/origin/fe4900027785c5df4817" alt="" width="304" height="299"></figure></div>
										  </div>