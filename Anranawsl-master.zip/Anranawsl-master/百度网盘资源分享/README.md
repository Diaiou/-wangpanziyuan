# 失效不补，请及时【 取 存 】哦！！！！！！！

### 公众号每天更新各种Svip、翻墙、线报、撸实物、搞机教程、各种网盘资源等等等。。。

<img src="https://p.pstatp.com/origin/137fe000238abec2d11ab" width="50%">

### [分享的所有网盘资源](http://pan.3kla.cn/dir/30378223-41531263-8cebcd)

<img src="https://p.pstatp.com/origin/1385300014d3ddb5be623" width="30%">

> 非百度网盘存储的资源：请关注公众号，回复 9 ，获取最新资源，不限速，非百度网盘存储

#### 今日最新资源分享（取消不补）配合[【杂 货 铺】](https://shop.3kla.cn) 8 毛的Svip即可去广告原画质观看

#### [点击获取今日更新12.30](http://pan.3kla.cn/dir/30378223-41547148-e3dcc6)



###### 12.8资源

<pre>
需要什么资源，直接 **公众号【失心人】**后台留言即可，找到会发你的，专业免费代招无损音乐


新增自动回复：

​				爵迹2冷血狂宴 4K             回复“ jj ”即可			

</pre>



## 12.7资源

<pre>
韩剧👇
惊奇的传闻
https://pan.baidu.com/s/1HFlY-trvYPfR73rh6LXueA 
Start Up（完结）
https://pan.baidu.com/s/1_bLzLUl3xx1l0dFkDxuDmQ 
Hush
https://pan.baidu.com/s/1rheX_ea9gsnTHDQwSm19QQ 
蛟龙飞天
https://pan.baidu.com/s/1l7oR2V2FHgkJXjPV0xEPTA 
Oh！三光别墅
https://pan.baidu.com/s/1nmHo8mdpFs-GXp-491FgZA 
补顶楼
https://pan.baidu.com/s/1yj7iHf0vhcOHu2wMTqrVSw 

国剧👇
大秦赋
https://pan.baidu.com/s/1dwZulQG7V-i4KneJK_Ptrw 
情深缘起
https://pan.baidu.com/s/1R_S1qttCjRc9oVU3oxUcPA 
从结婚开始恋爱（番外）
https://pan.baidu.com/s/1PNhDy7zCzEemgmsGhTvBEA 
了不起的儿科医生
https://pan.baidu.com/s/1sJduh3crVxfp7NDXT5GVZw
装台
https://pan.baidu.com/s/1YGBZHjds_KGC_L5vfsZxSw
与晨同光
https://pan.baidu.com/s/15hhISqfpP8lO5FVIXBSfSA
爱的厘米
https://pan.baidu.com/s/1pQzRhp-LfGkwz00bijvzqw
只为那一刻与你相见
https://pan.baidu.com/s/1Q04AEytSUOvEgMyZISvqGQ

台剧👇
王牌辩护人
https://pan.baidu.com/s/1_PHJrxKCaCT8ZLYvjp_9MA
粉红色时光
https://pan.baidu.com/s/1RRSyvHwBQn1tOvWuSB9Big
脑波小姐
https://pan.baidu.com/s/1wonetokVShRpFGpgau-PqQ
返校
https://pan.baidu.com/s/1LimDE-X2Ipj2Ve6RA4uAGQ 

泰剧👇
你是我的氧气（完结）
https://pan.baidu.com/s/16h-snteWwmApOiLu_990sg 
朋友圈2
https://pan.baidu.com/s/1fM2yvfsbKKGWCRBTHuPzbQ 
缘来誓你
https://pan.baidu.com/s/1AZy4Dk8fsAyL0_y2rO5Slw 

综艺👇
硬糖少女303团综+首唱会
https://pan.baidu.com/s/1xHwhRizwo-v8_g5oU-qRQw 
奋斗吧主播
https://pan.baidu.com/s/13MirC_R2DHNIOZBZwumqoQ 
宇宙打歌中心
https://pan.baidu.com/s/1GiCd4RCRw9mEJZeMOb0KQw 
补演员请就位2（导演终极作品）
https://pan.baidu.com/s/1KZn2RhyRevmEg8-d2cWAHQ 
姐妹们的茶话会
https://pan.baidu.com/s/1IaK02USt4MvTah00Mrg-bQ 
希望的田野
https://pan.baidu.com/s/1ufcxSap96EAhT3AtcdfO4w 
RM
https://pan.baidu.com/s/1gRQc3tfWL9We-jc5MZPBlw 
夜色中的地球.全6集
https://pan.baidu.com/s/1fNqgzXFpvxsq1HvraPaSXQ 
天天向上
https://pan.baidu.com/s/1rhREPWUXsfR89OVk854t_g

欧美剧👇
无耻之徒（美版）11
https://pan.baidu.com/s/1Ow0exHAi3gJl49joEhKqTQ 
权欲第二章
https://pan.baidu.com/s/1jUmRAG1Q6jQOKpIVjmZM-Q 
法官大人
https://pan.baidu.com/s/1GCvVcHFB7IDFTjbFauR5zA 
泪之谷（完结）
https://pan.baidu.com/s/1HcpBLMLVnRkP6jwyJ10y5A 
哈迪兄弟
https://pan.baidu.com/s/1Ga40PHYeGQ5VZnQD6QTkXA 

日剧👇
消除老师的方程式
https://pan.baidu.com/s/1vd8LW481WBAF9UZdc2A_Bw
Cold Case 3～真实之门～
https://pan.baidu.com/s/1hHMj2Tl1odd_x11tqQl5yQ 
24 Japan
https://pan.baidu.com/s/1zD1lGPJ880TkUbbLqV-uFg 
恋爱的母亲们
https://pan.baidu.com/s/1AtTPOwWqfOpzCw19N7jc7w 
春和苍的便当盒
https://pan.baidu.com/s/14wpHfjFro-sZ0ucODS51tQ 
我梦见了那个女孩
https://pan.baidu.com/s/1tVeuW_w6CcBANmQax2kLcQ 

动漫👇
进击的巨人 最终季（熟肉稍后）
https://pan.baidu.com/s/17mVTjKySfPVeLxaOedqyWg 
数码宝贝大冒险2020 重启
https://pan.baidu.com/s/1yEELPxv7LhLGc4Xa0nkREw 
海贼王
https://pan.baidu.com/s/1_ER8SinO-78BtEsrSrAldw 
吞噬星空
https://pan.baidu.com/s/1O12YGS3sw-YV_r8VUYVG7g 
剑网3·侠肝义胆沈剑心之长漂
https://pan.baidu.com/s/1VCaY3oCDpVHMmgk8eoIvMQ 
画仙纪之双月
https://pan.baidu.com/s/15dpyU_O5nQPVwgmgs9I5zw 
汉化日记2
https://pan.baidu.com/s/1voxnQeRad6dgFf-8FdaeZw 
英雄再临
https://pan.baidu.com/s/1b0IWKGkMN14ANYKe7jnblQ 
辣妹与恐龙
https://pan.baidu.com/s/1K4FNj-BQKi2YMZyc50meqA 
鬼灭之刃.中配版
https://pan.baidu.com/s/1C9lcZtz_8VAs1ecJwJfxXQ 
魔法科高中的劣等生 来访者篇
https://pan.baidu.com/s/1jPlkmZTrRz3nVyVJu5ofRQ 
攀岩sport climbing girls
https://pan.baidu.com/s/1eZyEEEJMKc-3PwmmQJ1HAQ 
甜梦猫
https://pan.baidu.com/s/1luYp6Kt38paj2qkin1FXpg
博人传
https://pan.baidu.com/s/1Kp1ma2o0oEuoy0wlM_Q7WQ
假面骑士圣刃
https://pan.baidu.com/s/1A8E2uvZmNohh9Y0Z_v4UBw
无能的奈奈
https://pan.baidu.com/s/1qz__JaJsdDKsmSlazNhZlw 
体操武士
https://pan.baidu.com/s/1uUVEtxRNdD0y4S6UOW2z2Q 
IDOLiSH7-偶像星愿- Second BEAT!
https://pan.baidu.com/s/1sIf_xWORjqIknRZRuP36FA 
前说！
https://pan.baidu.com/s/12dfNOJ2zmbWg_csI7jye4w 
被神捡到的男人
https://pan.baidu.com/s/1VIsHQ9IiaQnhpuN6onmW7g
奥特银河格斗 巨大阴谋
https://pan.baidu.com/s/1WXi-bCbRvKpugksru6LkfQ 
成神之日
https://pan.baidu.com/s/1UCyxRkZ0VnRc1TMFDp3jWQ

广播剧👇
SCI谜案集第四季（02）
https://pan.baidu.com/s/1JUW-o4HQxSitpb9BDQcoBQ 
总裁酷帅狂霸拽第二季（08上+下）
https://pan.baidu.com/s/1b8USCaxn5DRXPlolCgdF0A 
千秋第二季（15）
https://pan.baidu.com/s/1jNrElVE0T3fSFTMP2H3j0A 
鬓边不是海棠红（预告）
https://pan.baidu.com/s/1EAfLrPQpoaetZ7Y7Zldorg 
戏精守护者（04）
https://pan.baidu.com/s/1HKat3aulIP3p50qsWMUc7A 
等你下课（声展）
https://pan.baidu.com/s/1enpQ_pSrnWvwCzVIEvSa1g 
离婚前后（定档预告）
https://pan.baidu.com/s/1ZCzulTCh7-u0gWZvsVjBmA 
修罗爱情（01ed）
https://pan.baidu.com/s/1CAQ8tIiUFvT263WPjVHxDw 
三分星野（完结ft）
https://pan.baidu.com/s/1g0fgvdeEBVweLsPW056TYw 
绝对契合（充电提示音）
https://pan.baidu.com/s/1CxOZOTpxRKoPTWw5kmqMqA 
清嘉（01）
https://pan.baidu.com/s/1ILD3Hi7XjKIbPaww611Alg 
谷围南亭（06）
https://pan.baidu.com/s/1PLt6u9RaE1IC-akhUgHp8A 
响指（06）
https://pan.baidu.com/s/1k2CVLDESgUBp2sGsMYiDgw 
配音研究院（02上）
https://pan.baidu.com/s/1BNpRv9d7Zosrs0iSfUJDQw 
深宫囚（03片尾曲）
https://pan.baidu.com/s/1Bga4XbWf0SXJk6EbcdKavQ 
欧米伽档案（07）
https://pan.baidu.com/s/19pFOL_RhEhCQQROFvIbnNQ 
不成角 全一期
https://pan.baidu.com/s/1QLC4Mo9RR4fxSKFwJg1Oow 
有声剧 兼职无常后我红了（46）
https://pan.baidu.com/s/1KiAg--btDwR4vZNgDnMDHA 
还有一波有声剧明天更

天官赐福.漫画更46
https://pan.baidu.com/s/1D74cRgKHghFrzvZJ-ELZMQ 

电影👇
真假美猴王之大圣无双
https://pan.baidu.com/s/1sLnZwdtBMo08HPpx-RCIvg 
补鬼灭之刃 无限列车篇 TC版
https://pan.baidu.com/s/1SdYV8BQW7Tsq7KGy_Y1J7A 
补逃狱兄弟
https://pan.baidu.com/s/1idKFKRaLE0OYB3k2vvNwhA
</pre>





## 11.29资源（取消不补）

### 韩剧👇

哆哆嗖嗖啦啦嗖   
https://pan.baidu.com/s/1Kjlrllyq30jSCbFHo9Eozw  
爱我的间谍  
https://pan.baidu.com/s/13EltUxH-AyZw93TGWhLaBQ  
私生活  
https://pan.baidu.com/s/1AJNVOkQFzf-zTmfApmHw9w  

### 国剧👇

狼殿下（完结）
https://pan.baidu.com/s/1r2w7ulIHDrXtAeEtISlVqA   
狼殿下全集1080压缩版  
https://pan.baidu.com/s/1hFaU_E0XSXquTtMKcgTSlA   
提取码：u203   
亲爱的麻洋街.超（完结）  
全集1080无水印  
https://pan.baidu.com/s/1_ujhqc2PTsMJ7q8f40xZJw   
兄台请留步  
https://pan.baidu.com/s/1mrY3nwxBleDzu2OeIn6QAg   
最好的时代.DVD版  
https://pan.baidu.com/s/1q2sS2bGfWcNUE7DyEcqOmg  
燕云台.超42  
https://pan.baidu.com/s/1L5yy-KYc1etCq3_qX2dEBA   
鹿鼎记（含陈小春版）  
https://pan.baidu.com/s/1lTecl0GCNMTJ2AY5LYgaeA   
好想和你在一起  
https://pan.baidu.com/s/1kV1UCkBcdnWvMi0wjo9dzg   
最初的相遇，最后的别离  
https://pan.baidu.com/s/1HhjwA9hZh-C_2_vTv2LLbQ   
我有特殊沟通技巧  
https://pan.baidu.com/s/1RnIf4s_z0BN9zr1jzf_Z3A  
青春创世纪  
https://pan.baidu.com/s/13fZaJkYjeD4A0qJ1BBEl6Q   
黑色灯塔.超1080无水印全集+彩蛋  
https://pan.baidu.com/s/1Xsfvj0ZcDujefh_YaVYi8A   
隐秘而伟大  
https://pan.baidu.com/s/1Zjhir85PbyLhvjwb6VBpng   
棋魂  
https://pan.baidu.com/s/1sye0RRr7H36j1sm_zGXRTQ   
爱的厘米  
https://pan.baidu.com/s/1pQzRhp-LfGkwz00bijvzqw  

### 港剧

TVB版盲侠大律师/踩过界Ⅱ（无删）    
https://pan.baidu.com/s/118ptvIKMPPWgs-CJtFjr3A   
TVB版使徒行者3（无删）  
https://pan.baidu.com/s/1mU6YPTzCLEMFVFTb_aN65g  
暖男爸爸  
https://pan.baidu.com/s/1U82jxlCRMFT1Xkigm9svDg  
非凡三侠.全6集  
https://pan.baidu.com/s/1NEcs0iopfFJdqkADdJEbIw 

### 台剧👇

粉红色时光  
https://pan.baidu.com/s/1Gdn8tJ2BkMlIDYcJkp22OA   

### 综艺👇

明星大侦探互动衍生2之目标人物
（更新纯享版+超前付费番外）    
https://pan.baidu.com/s/1eX606AWRkk0WpM309JEQYw   
名侦探学院3  
https://pan.baidu.com/s/1ndrJH17CQNMZ7ntpBiI0YQ  

 早餐中国3  
https://pan.baidu.com/s/1Boc3gvuOngp7uvzFaJR3ig   
非日常派对  
https://pan.baidu.com/s/1aJ4kTiJBlGvy6Gip7-OT_w   
姐姐的爱乐之程（抢鲜版）  
https://pan.baidu.com/s/1BcXCCnobhKW5OfIikbTdRw   
女儿们的恋爱3（plus）  
https://pan.baidu.com/s/1H-ded3OH-JpJyl9dfUen2g   
小巨人运动会  
https://pan.baidu.com/s/1jO8pXts9GroQm-DIhasZfw   
幸福三重奏3  
https://pan.baidu.com/s/18bWKYsx9-s54YphDtEJg2w   
补令人心动的offer1-2  
https://pan.baidu.com/s/1hjdQMkVKJSviJvwT3n4MKw   

### 动漫👇

秦时明月之沧海横流  
https://pan.baidu.com/s/1LSyV-0Fb8YYn4tdtDvCW1g   
独步逍遥  
https://pan.baidu.com/s/1OFKQoXHbVnf3V5eM32OtYA   
我家大师兄是个反派  
https://pan.baidu.com/s/1snfJXoB7hQSxuZNjG7fdYQ   
强袭魔女 通往柏林之路  
https://pan.baidu.com/s/13MyvTvUuH4oIhfkkWnn_Qw   
小碧蓝幻想！  
https://pan.baidu.com/s/1ayW_DG7ZoFBSYk8G1xz9IA   
全员恶玉  
https://pan.baidu.com/s/1hFpanWeGWBTDOLn5BKxLnw   

### 泰剧👇

以你的心诠释我的爱（完结）  
https://pan.baidu.com/s/1NS0l32Z_jutzziR9Ti5gtQ  
谁的青春不乱爱  
https://pan.baidu.com/s/1Sf1z4lYlOA4suYHKu27VTA   
补不期而爱2.全集  
https://pan.baidu.com/s/1c5GZvxieABjufrC6njedBw   
嫉妒的密码  
https://pan.baidu.com/s/1_mkq6W2orb0LLY2-vrLUZA   

### 欧美剧

终生2  
https://pan.baidu.com/s/1-MOau8FwGvRje3vkGZ8xQA   
星际迷航：发现号3  
https://pan.baidu.com/s/1emhTQY7kmFyYd06ASQa0ZA   
芝加哥警署8  
https://pan.baidu.com/s/1jHYTt4Sdk8NGfwAkchohWA   
联邦调查局：通缉要犯2  
https://pan.baidu.com/s/128Y7kcNXW2lO4j3OOkr5zw  

### 日剧👇

一亿日元的告别（完结）  
https://pan.baidu.com/s/1oMDKTIXWbyMIkME6btvgWA   
共演NG  
https://pan.baidu.com/s/1dqSigdSGUQB8oBRQr6frqw   
单恋美食家日记  
https://pan.baidu.com/s/1k8lVpAXOD8ZbPH7K_Kzivg   
这份爱要加热吗  
https://pan.baidu.com/s/12Wl5BOJ-Bu99uFuhwHeNYQ   
姐姐的恋人  
https://pan.baidu.com/s/1f9KHSJ6URhnNWc1yzcYCVg   
帅哥选举  
https://pan.baidu.com/s/1q1YxLtxmqPKxvJrYLEh5Kg      
17.3关于性（完结）     
https://pan.baidu.com/s/1LQJoriuEbs88vYQj0cFj0Q         
远程恋爱    
https://pan.baidu.com/s/1SvC8VjObY4qYUVVw1sX4Ew    

### 广播剧👇

 

### 小说【11.16】

https://pan.baidu.com/s/1dg-jDWB-4eF4AeXZeC8-VQ  

### 姜子牙.1080P.115网盘

https://115.com/s/sw31qks36r1?password=u033&  
访问码：u033  
姜子牙.1080P.迅雷云  
https://pan.xunlei.com/s/VMMGwiA2hHF0EwUOEoVOxCDPA1 提取码:1gM8  
不提供度盘，连续上传3次，次次不出半小时直接和谐成净网片  

### 花木兰.1080国语

https://pan.baidu.com/s/1JDy6ofFmyYMcIoTjgOgYng  

<br>

## 11.18资源（取消不补）



### 韩剧👇

Oh！三光别墅  
https://pan.baidu.com/s/1mGvwksz1oBDdTqAXBvbhmQ  
搜索（1080P完结）  
https://pan.baidu.com/s/1efxJsR84ZXFC8Cl7iiOXgw  

### 国剧👇

隐秘而伟大  
https://pan.baidu.com/s/1L1BLEkiEjetuBDZx6Eddzw  
燕云台.超36  
https://pan.baidu.com/s/13sXnfjnm_qd282yGcuf3Yw  
鹿鼎记  
https://pan.baidu.com/s/1zZKyGdDz-5Z1llFo0rGbSQ  
瞄准（完结）  
https://pan.baidu.com/s/138EW2VNbHKfKjGEfOxiBcQ  
爱的厘米  
https://pan.baidu.com/s/1786XKxotE_xyowvdoXTSiQ  
追梦  
https://pan.baidu.com/s/16_Mhdv96yYRlCd4mSol8jg  

### 台剧  

天巡者  
https://pan.baidu.com/s/1qyQcfsdEoJvVy5Yt971dkw  
记忆浮岛  
https://pan.baidu.com/s/1AY9tqiznlA7TAT-obzB1-w  

### 港剧👇

TVB版使徒行者3（无删）  
https://pan.baidu.com/s/1mU6YPTzCLEMFVFTb_aN65g  

### 综艺👇

理想家  
https://pan.baidu.com/s/1tXS1IgaaGIyxNsqolLyNZg  

### 动漫👇

斗罗大陆  
https://pan.baidu.com/s/1NbqmVH5XAndEnQJx0_D3cA  
天官赐福  
https://pan.baidu.com/s/10e0qmtKVRAviZqXJVHFE3Q  
半妖的夜叉姬  
https://pan.baidu.com/s/1dWbVxmoDE4zYBLHpJlyK7w  
名侦探柯南  
https://pan.baidu.com/s/1TS7jVHXwe-nvqoUk8efiyA  
咒术回战  
https://pan.baidu.com/s/1USsJAuH8synjtltoy2wI7Q  
请问您今天要来点兔子吗？第三季  
https://pan.baidu.com/s/1K09L20qsxYi4fpfWNiAC9A  
大话之少年游  
https://pan.baidu.com/s/1BP4X2oGJeNqh65r_n7WtAA  
勇者斗恶龙 达伊的大冒险  
https://pan.baidu.com/s/1e07gXTcWIijq8NdRYEJLRg  
王之逆袭 意志的逆袭者  
https://pan.baidu.com/s/1PlWn-oBYGdE7DiJEbFuhsA  
铁路浪漫谭  
https://pan.baidu.com/s/125_16A_dcuptkcZG_SNKCQ  
成神之日  
https://pan.baidu.com/s/1UCyxRkZ0VnRc1TMFDp3jWQ  
战翼的希格德莉法  
https://pan.baidu.com/s/1TE3ayqvQymQb6XrGuSJhCQ  
Love Live! 虹咲学园校园偶像同好会  
https://pan.baidu.com/s/1re1wCylbTvlN5xqUwNyLLQ  

### 泰剧👇

超凡少年毕业季/特长生2  
https://pan.baidu.com/s/1TIvOvmmqXDCr2vuUJ6En6w  
情梅竹马  
https://pan.baidu.com/s/1GAUX7cv9ZTjcDhPzQ1lQQg  
褪色的回忆  
https://pan.baidu.com/s/1UZS8SG4eXDJvqOe5RON-Tw  

### 欧美剧

黑暗物质三部曲2  
https://pan.baidu.com/s/1IcwamO_aefX8es2srMQmDw  
小斧子  
https://pan.baidu.com/s/1t3bLBugQFZpomti94JfsZw  
冰雪暴4  
https://pan.baidu.com/s/1cM-_TrU7fNybiDNQjYEU-Q  
行尸之惧6  
https://pan.baidu.com/s/1lWKeCuHWFztf_XYvAOKn0Q  
西班牙公主2  
https://pan.baidu.com/s/1cFDZEvP4lsVcIqygFNFOmA  
无所作为  
https://pan.baidu.com/s/1k8LZ4g76mCwD15jIsmeqCw  

### 日剧👇

极主夫道  
https://pan.baidu.com/s/1M1ut6FufYeE_q_LV08XyDg  
危险的维纳斯  
https://pan.baidu.com/s/1CGIpf3p9HBBCxWZs76u7fw  
阎魔堂沙罗的推理奇谭  
https://pan.baidu.com/s/1f-Ft8pIojlp4BF53Y9Swbg  
所以我化妆（完结）  
https://pan.baidu.com/s/1iTj7ktK45HR4vUO4VuOYNQ  
草莓之歌  
https://pan.baidu.com/s/1uA_rB9CIaWLPk5SlLwpCnQ  

### 广播剧👇

广播剧  
补将进酒（第一季和谐的06重置已补）  
https://pan.baidu.com/s/1pMcCyrg4jHc576DtjzoWNg  
默读 第五季（16）  
https://pan.baidu.com/s/1RHlKPxxLBCcpENDhygaRJw   
大家好，我跟男二在一起了（05）  
https://pan.baidu.com/s/1ojUR7xEl5WhTaJgM-cYv0g   
你的距离（小剧场03）  
https://pan.baidu.com/s/196-ORG4Cf-H1zm5Rir7Gog   
窥光（08）  
https://pan.baidu.com/s/1cpn2k6gKIUrRIV10zrD0RA   
三体第四季（05）  
https://pan.baidu.com/s/1_YUDaNlDPACmMAox_bMt7A   
某某（抒情版伴奏）  
https://pan.baidu.com/s/1A9QRXEJZuvWaLekgH0OYKg   
不舍（01）  
https://pan.baidu.com/s/1Aqnnxxw8vbOT4OtEnGEY_g   
不死堂（02）  
https://pan.baidu.com/s/1aqTwvSEa06gWw-Lo9_B_uA   
补解药（别的没和谐，海报和谐了，迷惑）  
https://pan.baidu.com/s/1zuiCIfdETQEJWx7wa5__4Q   
白夜追凶（33）  
https://pan.baidu.com/s/1k3QtmJolGtGn5RdJ2zpCBQ   
半截的诗（小剧场1）  
https://pan.baidu.com/s/1sCIcsUJ4PKQlvZT_fV9MgA   
诞下龙种吧（12ED）  
https://pan.baidu.com/s/1TYRpbNmtwgwq1BtxtBJsRg   
DOLO命运胶囊（10）  
https://pan.baidu.com/s/1yGllwUc_oMF9vDDPdw5H0A   
技术入股 全一期   
https://pan.baidu.com/s/1wvcP-S7dpuNN2OA4eGAoGA   
恰逢其时 全一期  
https://pan.baidu.com/s/16ejA-z10zm44RU_OcefdxA   
篮球场上 全一期  
https://pan.baidu.com/s/1mOQEbLGEC59cL-67Bkg9cg   
有声剧 势不可挡   
https://pan.baidu.com/s/1WYuJNVAy983s6o9hnH2Suw   
有声剧 这题超纲了（74）   
https://pan.baidu.com/s/13xwJBq9yNvqR-G8CQc7KmA   
有声剧 龙图案卷集574-591，前面还缺了一些，后续补  
https://pan.baidu.com/s/1SB3uRwrCyk13yvd7gELDXA   
有声剧 拐个男友玩养成  
https://pan.baidu.com/s/1oKqUPSLjRqQoTUY6nD0f8A   
有声剧 浮云半书  
https://pan.baidu.com/s/12c75JuFRnqq--u0dkIh5Eg   
有声剧 总裁的逆袭  
https://pan.baidu.com/s/1fHyjvy8sm_06updRFaoAHw   
有声剧 骷髅幻戏图  
https://pan.baidu.com/s/1JcuQnb_v80wlse30GJpzgQ   
有声剧 奈何男妻太倾城  
https://pan.baidu.com/s/1dmDVFpqPrq2uP4_oFbEnHA   

### 小说【11.16】

https://pan.baidu.com/s/1Z4hecpIFmkSZuNPCrw1z9Q   
小说【11.19】【2】  
https://pan.baidu.com/s/1zmqqvARXCigab1kVP-xtyQ   

### 姜子牙.4K

4K，压缩包，我估计压缩包也会和谐，保存后马上下载，在线解压出来就是8秒，别手贱点在线解压！！  
https://pan.baidu.com/s/18dV3XW7mU26Xuz0fmTv0tg  

<br>

---

## 11.15资源

### 韩剧👇

蛟龙飞天  
https://pan.baidu.com/s/1WgpfLqCrdupid3Vp3Cixqw  
境遇之数  
https://pan.baidu.com/s/1ePLs6tXVLBwK-CpuElQsMw  
Start Up  
https://pan.baidu.com/s/1cXhUGW3obJyR_vMShE8YDw  
搜索  
https://pan.baidu.com/s/1efxJsR84ZXFC8Cl7iiOXgw  

### 国剧👇

隐秘而伟大  
https://pan.baidu.com/s/1Dfl_-jCa0lpGwDmjWDQorA  
以父之名  
https://pan.baidu.com/s/1nRiwZ-ODocvj81rlZsfTwg  
燕云台  
https://pan.baidu.com/s/1Rm08quQUF4_EWqw24MNi1w  
你听起来很甜  
https://pan.baidu.com/s/1gQRmDUSwwD17quPx2CCWqQ  
补九流霸主  
https://pan.baidu.com/s/1O234xLXy9l1oPr-2MQgi7A  
瞄准  
https://pan.baidu.com/s/1TGH1A9kcxJ9QkRnaM25lWQ  
越过山丘（完结）
https://pan.baidu.com/s/16kzCZII-fe2OBi2dvMqtmw  
创业年代（完结）
https://pan.baidu.com/s/1xZJAefk9GACvr4rOlHNXQw  
向阳而生停播  
云端.全两季4K  
https://pan.baidu.com/s/11xmW1Xnt2jA9pFsxfFKRNQ  

### 港剧👇

馋上你  
https://pan.baidu.com/s/1T_kzWU1eRPt5GbWA1r8QZg  
因为我喜欢你  
https://pan.baidu.com/s/1NQY1kup_aw-t6Ea1YkGKzw  

### 综艺👇

演员请就位2  
https://pan.baidu.com/s/1xc_3PtNy13G6aoU9sCyq0w  
说唱新世代（会员）
https://pan.baidu.com/s/1EbqPQjuZreiKdxb5GZj-pw  
这就是灌篮3  
https://pan.baidu.com/s/1CDv4OrdWeD2HFZGeDyTEIg  
守护解放西2  
https://pan.baidu.com/s/1jutSo1PGprvYmwgWfwnflg  
姐姐的爱乐之程（plus）
https://pan.baidu.com/s/1bSERt1bMhF9Ej7JbI-pgwg  
哎呀好身材2  
https://pan.baidu.com/s/1czQWY65Ncoo1Ld3O3JCzVw  
奋斗吧主播  
https://pan.baidu.com/s/14Ph8k6h05MLetRrjUcFsCQ  
新西游记8  
https://pan.baidu.com/s/1GoM229EWQM6uDxAXDqDmpA  
跨次元新星  
https://pan.baidu.com/s/1vRbZqjScmUzvZ7laGlvXPg  
神奇公司在哪里  
https://pan.baidu.com/s/1_v3c0zUoFbJxKTIvUte_Ng  
快乐大本营  
https://pan.baidu.com/s/1igR7v4WwZ1dEc0KkbddUvA#/
完美的夏天  
https://pan.baidu.com/s/1vFLp-fwVULZiZvlCS8-D6Q  
来者何人  
https://pan.baidu.com/s/1mQ48bZPYjyIUaLd2VNe7Ew  
美好的时光  
https://pan.baidu.com/s/1wc6YTOGKV_3K80kazO-3Rw  
上新了故宫3  
https://pan.baidu.com/s/1oeGkDTCGoWUMLB-aclpKPA  
舞蹈风暴2  
https://pan.baidu.com/s/15I1IOJVxVGJe6tvjIY4rUA  

### 动漫👇

斗罗大陆  
https://pan.baidu.com/s/1NbqmVH5XAndEnQJx0_D3cA  
天官赐福  
https://pan.baidu.com/s/10e0qmtKVRAviZqXJVHFE3Q  
半妖的夜叉姬  
https://pan.baidu.com/s/1dWbVxmoDE4zYBLHpJlyK7w  
名侦探柯南  
https://pan.baidu.com/s/1TS7jVHXwe-nvqoUk8efiyA  
咒术回战  
https://pan.baidu.com/s/1USsJAuH8synjtltoy2wI7Q  
请问您今天要来点兔子吗？第三季  
https://pan.baidu.com/s/1K09L20qsxYi4fpfWNiAC9A  
大话之少年游  
https://pan.baidu.com/s/1BP4X2oGJeNqh65r_n7WtAA  
勇者斗恶龙 达伊的大冒险  
https://pan.baidu.com/s/1e07gXTcWIijq8NdRYEJLRg  
王之逆袭 意志的逆袭者  
https://pan.baidu.com/s/1PlWn-oBYGdE7DiJEbFuhsA  
铁路浪漫谭  
https://pan.baidu.com/s/125_16A_dcuptkcZG_SNKCQ  
成神之日  
https://pan.baidu.com/s/1UCyxRkZ0VnRc1TMFDp3jWQ  
战翼的希格德莉法  
https://pan.baidu.com/s/1TE3ayqvQymQb6XrGuSJhCQ  
Love Live! 虹咲学园校园偶像同好会  
https://pan.baidu.com/s/1re1wCylbTvlN5xqUwNyLLQ  

### 泰剧👇

朋友圈2  
https://pan.baidu.com/s/123g6x3Zu2Fqg6Uubjs6qwg  
无可替代（完结）
https://pan.baidu.com/s/1qSFgyOCQJbtKgFSRmaBk2Q  
褪色的回忆  
https://pan.baidu.com/s/1VNgTCljBMzd3U-XHgGIvwg  

### 欧美剧

战士2  
https://pan.baidu.com/s/1Ee_Cu01gPfQgOaEOuNcNBQ  
太空先锋  
https://pan.baidu.com/s/1M5bURU6daF3EiEVTo0-ZRg  
爱情不设限（完结）
https://pan.baidu.com/s/1l701nhOjUhgT3HIjCbS1pQ  

### 日剧👇

鲁邦之女2  
https://pan.baidu.com/s/1mveTsxgGwG7Gy-PJGQ8IGg  
七个秘书  
https://pan.baidu.com/s/14N8h7hxfOOe7lYvWTSbcGw  
我们不危险华丽地偷懒的刑警们（完结）
https://pan.baidu.com/s/1V335uqid8HF2PIkFgAj-3Q  
恋爱的母亲们  
https://pan.baidu.com/s/1sAfOLfcRzkYTNkOXLQxIhw  
17.3关于性  
https://pan.baidu.com/s/1G92-t0XriAca0KreDBWncw  
科搜研之女20  
https://pan.baidu.com/s/1g5hDJYZ_dJxRqwjdTsPMzw  
我梦见了那个女孩  
https://pan.baidu.com/s/17LwBh1gNlqc-h2hJrJlQmw  
24 Japan  
https://pan.baidu.com/s/1BllRcO3PqcNBmuJZ2i4uow  

### 广播剧👇

FOG（12）
https://pan.baidu.com/s/1l06xA8BVBwxygzZoReq7UA  
飞鸥不下（06）
https://pan.baidu.com/s/1aU3tooX6f-be62N36ruKTA  
骷髅幻戏图（09）
https://pan.baidu.com/s/1011V7KDizwgkDSRpVzwHqA  
SCI谜案集第三季（小剧场）
https://pan.baidu.com/s/1Kkf7xUbeHqAnQubTQoo9YA  
穷途（06）
https://pan.baidu.com/s/11ZULcBk67d0OgHWJIj5JMA  
我们的十二年一个轮回，这是传奇（07）
https://pan.baidu.com/s/1sBgke7LWPf2JSQRCdqcJKw  
漂白的爱情（03）
https://pan.baidu.com/s/1L8m_lAIehq2j_ECUt8Y0hA  
哪里来的大宝贝（16）
https://pan.baidu.com/s/1q-YA7A4GH0Btu_O0xVzbbA  
饼干（02）
https://pan.baidu.com/s/14hiKSDobH1D-tJEUklP2Vg  
悍妻（01）
https://pan.baidu.com/s/1Nb0fOqSV6msOZgu7iEFruw  
DOLO命运胶囊（07）
https://pan.baidu.com/s/1IrXhB_i83BTfGjsJlm7Jeg  
楚留香传奇第二季（04）
https://pan.baidu.com/s/1mVPh_h1vi1xtpZGJlnXupg  
有匪第三季（12）
https://pan.baidu.com/s/1bg1QooIGoP3P4sUFuYKM5g  
重生（35）
https://pan.baidu.com/s/17PL3Q2x8v_DKBQ9xotLJ1g  
雪中悍刀行（117）
https://pan.baidu.com/s/1fs1OdOWj54OZ7ea4WP3m_A  
天之下（02章11）
https://pan.baidu.com/s/1YjLNkq3OcqnBhMcqgVQy8w  
天域神座（57）
https://pan.baidu.com/s/1eTbJzu9QDZvVrej_RGf6hg  
你微笑时很美（02）
https://pan.baidu.com/s/1Y6Qg5NCl2ICZD0KkluysgA  
镇魂街第二季（41）
https://pan.baidu.com/s/1vD_yc7GH6WjnHod5-hZ3LA  
感谢你是爱我的（09）
https://pan.baidu.com/s/1nkClSGTppSHlJaltmcPG1g  
绝代双骄（07）
https://pan.baidu.com/s/1UwJ_N5cG4cXuDlI8ShyL8A  
面具之下第二季（14章04）
https://pan.baidu.com/s/1X1SXNGsFcHILfXO7Qh5RiA  
枪爷异闻录（49）
https://pan.baidu.com/s/1SoiYOjoKYh2QdWKexVB3qw  
这题超纲了（63）
https://pan.baidu.com/s/1ldKuHfhcvjL4X5rBQwF8Gg  
一人之下（39）
https://pan.baidu.com/s/1yA9_BDYVJ1FoFzGeXSghuw  
偷香（500w福利）
https://pan.baidu.com/s/1XlMZPFXkLl1JBn1cNRBPMA  
欧米伽档案（03）
https://pan.baidu.com/s/1CwByqYLsrKwHJUkms-dEhQ  
捌年有幸（ED）
https://pan.baidu.com/s/1PMIZux3vPNy7-5UW1Z1CGQ  
动态漫画 真理面具（04）
https://pan.baidu.com/s/1gbzwgHV7Nzes7Uns3-aX7Q  
动态漫画 大唐遗案录（08）
https://pan.baidu.com/s/1eTvYSFOH9LvQK7ZpOW1l-Q  
动态漫画 我独自盗墓（12）
https://pan.baidu.com/s/1LYtpJso6ZWRQrlNxADEYWg  
有声漫画 夜勤科（12）
https://pan.baidu.com/s/1-0iXVlT3SQi0nTHVzVUDFw  
对决（完结）
https://pan.baidu.com/s/1DfdzWipYY4Z_MCxfIruphQ  
落不下 百万福利  
https://pan.baidu.com/s/1iJ7vpjdEZ8lkZubp_ujNmw  
日常二三事系列之输入法 全一期  
https://pan.baidu.com/s/1Awgj2c-NHFvVr0l40WIBGQ  
梅开二度 全一期  
https://pan.baidu.com/s/1DtPenrp4VuxyEXu-HCIkaQ  
南康白起 全一期  
https://pan.baidu.com/s/1BLzAOVF02c-K1VASkQOThw  
小蘑菇剧情歌  
https://pan.baidu.com/s/1lIPf_7MZoh6dvsw5vmSGNg  
2020倒霉死勒生贺  
https://pan.baidu.com/s/1C5VEDLvw2gvlPNEkqHT79w  
2020钱文青生贺  
https://pan.baidu.com/s/1WjGbk_RTvvUAoK1t33ZmTw  
20201106景向谁依直播回放  
https://pan.baidu.com/s/18khbovYjhAe67vhAHKnzVA  
【有声剧】共24部更新，1部完结  
https://pan.baidu.com/s/1VT0f2d1g2tlEaOnDInfAzA  

### 天官赐福.漫画更42

https://pan.baidu.com/s/18CBBuk-XLdntO5WgKKykWA  

### 小说【11.07】

https://pan.baidu.com/s/19d-BysANo-JanPPu2d3Cmg  

<br>

## 11.10资源

### 韩剧👇

蛟龙飞天  
https://pan.baidu.com/s/1WgpfLqCrdupid3Vp3Cixqw  
境遇之数  
https://pan.baidu.com/s/1ePLs6tXVLBwK-CpuElQsMw  
Start Up  
https://pan.baidu.com/s/1cXhUGW3obJyR_vMShE8YDw  
搜索  
https://pan.baidu.com/s/1efxJsR84ZXFC8Cl7iiOXgw  

### 国剧👇

隐秘而伟大  
https://pan.baidu.com/s/1Dfl_-jCa0lpGwDmjWDQorA  
以父之名  
https://pan.baidu.com/s/1nRiwZ-ODocvj81rlZsfTwg  
燕云台  
https://pan.baidu.com/s/1Rm08quQUF4_EWqw24MNi1w  
你听起来很甜  
https://pan.baidu.com/s/1gQRmDUSwwD17quPx2CCWqQ  
补九流霸主  
https://pan.baidu.com/s/1O234xLXy9l1oPr-2MQgi7A  
瞄准  
https://pan.baidu.com/s/1TGH1A9kcxJ9QkRnaM25lWQ  
越过山丘（完结）
https://pan.baidu.com/s/16kzCZII-fe2OBi2dvMqtmw  
创业年代（完结）
https://pan.baidu.com/s/1xZJAefk9GACvr4rOlHNXQw  
向阳而生停播  
云端.全两季4K  
https://pan.baidu.com/s/11xmW1Xnt2jA9pFsxfFKRNQ  

### 港剧👇

馋上你  
https://pan.baidu.com/s/1T_kzWU1eRPt5GbWA1r8QZg  
因为我喜欢你  
https://pan.baidu.com/s/1NQY1kup_aw-t6Ea1YkGKzw  

### 综艺👇

演员请就位2  
https://pan.baidu.com/s/1xc_3PtNy13G6aoU9sCyq0w  
说唱新世代（会员）
https://pan.baidu.com/s/1EbqPQjuZreiKdxb5GZj-pw  
这就是灌篮3  
https://pan.baidu.com/s/1CDv4OrdWeD2HFZGeDyTEIg  
守护解放西2  
https://pan.baidu.com/s/1jutSo1PGprvYmwgWfwnflg  
姐姐的爱乐之程（plus）
https://pan.baidu.com/s/1bSERt1bMhF9Ej7JbI-pgwg  
哎呀好身材2  
https://pan.baidu.com/s/1czQWY65Ncoo1Ld3O3JCzVw  
奋斗吧主播  
https://pan.baidu.com/s/14Ph8k6h05MLetRrjUcFsCQ  
新西游记8  
https://pan.baidu.com/s/1GoM229EWQM6uDxAXDqDmpA  
跨次元新星  
https://pan.baidu.com/s/1vRbZqjScmUzvZ7laGlvXPg  
神奇公司在哪里  
https://pan.baidu.com/s/1_v3c0zUoFbJxKTIvUte_Ng  
快乐大本营  
https://pan.baidu.com/s/1igR7v4WwZ1dEc0KkbddUvA#/
完美的夏天  
https://pan.baidu.com/s/1vFLp-fwVULZiZvlCS8-D6Q  
来者何人  
https://pan.baidu.com/s/1mQ48bZPYjyIUaLd2VNe7Ew  
美好的时光  
https://pan.baidu.com/s/1wc6YTOGKV_3K80kazO-3Rw  
上新了故宫3  
https://pan.baidu.com/s/1oeGkDTCGoWUMLB-aclpKPA  
舞蹈风暴2  
https://pan.baidu.com/s/15I1IOJVxVGJe6tvjIY4rUA  

### 动漫👇

斗罗大陆  
https://pan.baidu.com/s/1NbqmVH5XAndEnQJx0_D3cA  
天官赐福  
https://pan.baidu.com/s/10e0qmtKVRAviZqXJVHFE3Q  
半妖的夜叉姬  
https://pan.baidu.com/s/1dWbVxmoDE4zYBLHpJlyK7w  
名侦探柯南  
https://pan.baidu.com/s/1TS7jVHXwe-nvqoUk8efiyA  
咒术回战  
https://pan.baidu.com/s/1USsJAuH8synjtltoy2wI7Q  
请问您今天要来点兔子吗？第三季  
https://pan.baidu.com/s/1K09L20qsxYi4fpfWNiAC9A  
大话之少年游  
https://pan.baidu.com/s/1BP4X2oGJeNqh65r_n7WtAA  
勇者斗恶龙 达伊的大冒险  
https://pan.baidu.com/s/1e07gXTcWIijq8NdRYEJLRg  
王之逆袭 意志的逆袭者  
https://pan.baidu.com/s/1PlWn-oBYGdE7DiJEbFuhsA  
铁路浪漫谭  
https://pan.baidu.com/s/125_16A_dcuptkcZG_SNKCQ  
成神之日  
https://pan.baidu.com/s/1UCyxRkZ0VnRc1TMFDp3jWQ  
战翼的希格德莉法  
https://pan.baidu.com/s/1TE3ayqvQymQb6XrGuSJhCQ  
Love Live! 虹咲学园校园偶像同好会  
https://pan.baidu.com/s/1re1wCylbTvlN5xqUwNyLLQ  

### 泰剧👇

朋友圈2  
https://pan.baidu.com/s/123g6x3Zu2Fqg6Uubjs6qwg  
无可替代（完结）
https://pan.baidu.com/s/1qSFgyOCQJbtKgFSRmaBk2Q  
褪色的回忆  
https://pan.baidu.com/s/1VNgTCljBMzd3U-XHgGIvwg  

### 欧美剧

战士2  
https://pan.baidu.com/s/1Ee_Cu01gPfQgOaEOuNcNBQ  
太空先锋  
https://pan.baidu.com/s/1M5bURU6daF3EiEVTo0-ZRg  
爱情不设限（完结）
https://pan.baidu.com/s/1l701nhOjUhgT3HIjCbS1pQ  

### 日剧👇

鲁邦之女2  
https://pan.baidu.com/s/1mveTsxgGwG7Gy-PJGQ8IGg  
七个秘书  
https://pan.baidu.com/s/14N8h7hxfOOe7lYvWTSbcGw  
我们不危险华丽地偷懒的刑警们（完结）
https://pan.baidu.com/s/1V335uqid8HF2PIkFgAj-3Q  
恋爱的母亲们  
https://pan.baidu.com/s/1sAfOLfcRzkYTNkOXLQxIhw  
17.3关于性  
https://pan.baidu.com/s/1G92-t0XriAca0KreDBWncw  
科搜研之女20  
https://pan.baidu.com/s/1g5hDJYZ_dJxRqwjdTsPMzw  
我梦见了那个女孩  
https://pan.baidu.com/s/17LwBh1gNlqc-h2hJrJlQmw  
24 Japan  
https://pan.baidu.com/s/1BllRcO3PqcNBmuJZ2i4uow  

### 广播剧👇

FOG（12）
https://pan.baidu.com/s/1l06xA8BVBwxygzZoReq7UA  
飞鸥不下（06）
https://pan.baidu.com/s/1aU3tooX6f-be62N36ruKTA  
骷髅幻戏图（09）
https://pan.baidu.com/s/1011V7KDizwgkDSRpVzwHqA  
SCI谜案集第三季（小剧场）
https://pan.baidu.com/s/1Kkf7xUbeHqAnQubTQoo9YA  
穷途（06）
https://pan.baidu.com/s/11ZULcBk67d0OgHWJIj5JMA  
我们的十二年一个轮回，这是传奇（07）
https://pan.baidu.com/s/1sBgke7LWPf2JSQRCdqcJKw  
漂白的爱情（03）
https://pan.baidu.com/s/1L8m_lAIehq2j_ECUt8Y0hA  
哪里来的大宝贝（16）
https://pan.baidu.com/s/1q-YA7A4GH0Btu_O0xVzbbA  
饼干（02）
https://pan.baidu.com/s/14hiKSDobH1D-tJEUklP2Vg  
悍妻（01）
https://pan.baidu.com/s/1Nb0fOqSV6msOZgu7iEFruw  
DOLO命运胶囊（07）
https://pan.baidu.com/s/1IrXhB_i83BTfGjsJlm7Jeg  
楚留香传奇第二季（04）
https://pan.baidu.com/s/1mVPh_h1vi1xtpZGJlnXupg  
有匪第三季（12）
https://pan.baidu.com/s/1bg1QooIGoP3P4sUFuYKM5g  
重生（35）
https://pan.baidu.com/s/17PL3Q2x8v_DKBQ9xotLJ1g  
雪中悍刀行（117）
https://pan.baidu.com/s/1fs1OdOWj54OZ7ea4WP3m_A  
天之下（02章11）
https://pan.baidu.com/s/1YjLNkq3OcqnBhMcqgVQy8w  
天域神座（57）
https://pan.baidu.com/s/1eTbJzu9QDZvVrej_RGf6hg  
你微笑时很美（02）
https://pan.baidu.com/s/1Y6Qg5NCl2ICZD0KkluysgA  
镇魂街第二季（41）
https://pan.baidu.com/s/1vD_yc7GH6WjnHod5-hZ3LA  
感谢你是爱我的（09）
https://pan.baidu.com/s/1nkClSGTppSHlJaltmcPG1g  
绝代双骄（07）
https://pan.baidu.com/s/1UwJ_N5cG4cXuDlI8ShyL8A  
面具之下第二季（14章04）
https://pan.baidu.com/s/1X1SXNGsFcHILfXO7Qh5RiA  
枪爷异闻录（49）
https://pan.baidu.com/s/1SoiYOjoKYh2QdWKexVB3qw  
这题超纲了（63）
https://pan.baidu.com/s/1ldKuHfhcvjL4X5rBQwF8Gg  
一人之下（39）
https://pan.baidu.com/s/1yA9_BDYVJ1FoFzGeXSghuw  
偷香（500w福利）
https://pan.baidu.com/s/1XlMZPFXkLl1JBn1cNRBPMA  
欧米伽档案（03）
https://pan.baidu.com/s/1CwByqYLsrKwHJUkms-dEhQ  
捌年有幸（ED）
https://pan.baidu.com/s/1PMIZux3vPNy7-5UW1Z1CGQ  
动态漫画 真理面具（04）
https://pan.baidu.com/s/1gbzwgHV7Nzes7Uns3-aX7Q  
动态漫画 大唐遗案录（08）
https://pan.baidu.com/s/1eTvYSFOH9LvQK7ZpOW1l-Q  
动态漫画 我独自盗墓（12）
https://pan.baidu.com/s/1LYtpJso6ZWRQrlNxADEYWg  
有声漫画 夜勤科（12）
https://pan.baidu.com/s/1-0iXVlT3SQi0nTHVzVUDFw  
对决（完结）
https://pan.baidu.com/s/1DfdzWipYY4Z_MCxfIruphQ  
落不下 百万福利  
https://pan.baidu.com/s/1iJ7vpjdEZ8lkZubp_ujNmw  
日常二三事系列之输入法 全一期  
https://pan.baidu.com/s/1Awgj2c-NHFvVr0l40WIBGQ  
梅开二度 全一期  
https://pan.baidu.com/s/1DtPenrp4VuxyEXu-HCIkaQ  
南康白起 全一期  
https://pan.baidu.com/s/1BLzAOVF02c-K1VASkQOThw  
小蘑菇剧情歌  
https://pan.baidu.com/s/1lIPf_7MZoh6dvsw5vmSGNg  
2020倒霉死勒生贺  
https://pan.baidu.com/s/1C5VEDLvw2gvlPNEkqHT79w  
2020钱文青生贺  
https://pan.baidu.com/s/1WjGbk_RTvvUAoK1t33ZmTw  
20201106景向谁依直播回放  
https://pan.baidu.com/s/18khbovYjhAe67vhAHKnzVA  
【有声剧】共24部更新，1部完结  
https://pan.baidu.com/s/1VT0f2d1g2tlEaOnDInfAzA  

## 11.5资源

### 韩剧👇

九尾狐传  
https://pan.baidu.com/s/1_F1TQQ8a1t5x2lPRsLK1uQ  
顶楼  
https://pan.baidu.com/s/1E6bNrv5v5v7_tuXgKiJ6xw  
产后调理院  
https://pan.baidu.com/s/19NUKHztIX7eC6StnEl8DOQ  
我的危险妻子  
https://pan.baidu.com/s/1syIFIsYYDmO-5XE7UgNi6Q  
18 Again  
https://pan.baidu.com/s/1Tyue1wT8T0lJuSTwMvrHkQ  
空洞  
https://pan.baidu.com/s/1-OIPbEYvBaEdq6EU_UY-1A  
无声.韩影  
https://pan.baidu.com/s/1arr3hurh2JjaAt4IexR6_A  
哆哆嗖嗖啦啦嗖  
https://pan.baidu.com/s/1NgHOAJQf4L6ZU2LIGDg9EQ  
私生活  
https://pan.baidu.com/s/1_wO2H5IZKGfsQQpdzx-2_A  
### 国剧👇

黑色灯塔.超前至22  
https://pan.baidu.com/s/1h1ZRcLzuu-WyTIwdf30f9Q  
如意芳菲  
https://pan.baidu.com/s/1IAUhdDmP_GUZV77kT1FkKQ  
破茧  
https://pan.baidu.com/s/1v-kUChI7nS2JGqgVQ1OxSw  
九流霸主.超前至30  
https://pan.baidu.com/s/1GN5lnhnIT78bOAHD4yzwYA  
亲爱的设计师  
https://pan.baidu.com/s/1KEm48N8Cip6nIw7IwkuVnw  
棋魂  
https://pan.baidu.com/s/1t53COrvUEsAG-42WdfEldA  
燕云台  
https://pan.baidu.com/s/1n0XwFJceHgRT4Ngaj-5O0g  
云端  
https://pan.baidu.com/s/19cNRjdnyNrY2uV1o-xSeZg  
瞄准  
https://pan.baidu.com/s/1fqItkYfjd6ICm8VvUk-5ZQ  
向阳而生  
https://pan.baidu.com/s/1rm5He92GAKoUmNDIVZSmhQ  
创业年代  
https://pan.baidu.com/s/1Fy88NPEJAI7ysnYoZStmdw  
越过山丘  
https://pan.baidu.com/s/1TMNiJ2y5nqrEfXCFedbSKw  
### 港剧👇

盲侠大律师  
https://pan.baidu.com/s/1hf63SIvu_JfBbs8dxyf5MA  
使徒行者3.全集  
https://pan.baidu.com/s/1CwcOH-OI7-OkuG3w_lOE6g  
暖男爸爸  
https://pan.baidu.com/s/1U82jxlCRMFT1Xkigm9svDg  
木棘证人  
https://pan.baidu.com/s/1wihET8N8pzn0tPswIh3Nbw  

### 综艺👇

令人心动的offer2  
https://pan.baidu.com/s/1ausKGNgHmOqM0MxNtMeJYw  
我们恋爱吧2  
https://pan.baidu.com/s/1rQq4vpfHIYtT2jxnM6yKKw  
女儿们的恋爱3  
https://pan.baidu.com/s/1EKgQjS_Xcw9dR3__af8P8w  
新四季歌  
https://pan.baidu.com/s/10CBndHurs--KqBCt1U0w4w  
心动的信号3  
https://pan.baidu.com/s/1tdVz6OXioXp2iujh4FMOeg  
落地成双  
https://pan.baidu.com/s/1q3tNQ60Zs0dxSELm-AQvoA  
德云斗笑社.共享.拿完退  
https://pan.baidu.com/s/4bvPCxB5  

### 动漫👇

大贵族  
https://pan.baidu.com/s/1WFIlI3EBEZapTrd2DpwGuQ  
土下座跪求给看  
https://pan.baidu.com/s/1uy72zaBQFjTJH_4-v6RLOA  
你与我最后的战场，亦或是世界起始的圣战  
https://pan.baidu.com/s/1ooNQqS7SRx75__MxktnxCg  
超龙珠英雄BM  
https://pan.baidu.com/s/1xm8dir7O65F5MTo2pNmFsA  
一念永恒  
https://pan.baidu.com/s/1BiY6GNeJju2fkXtY9ORcmg  
拾忆长安·明月几时有  
https://pan.baidu.com/s/13u5LQ4k2O8Yz7HxmeMBVHA  
熊熊勇闯异世界  
https://pan.baidu.com/s/1bhqbzUxwYnZARc--1zZcMg  
月歌 第二季  
https://pan.baidu.com/s/1Va9H7XFKfg15z13IwjN-xg  

### 泰剧👇

男校风云  
https://pan.baidu.com/s/10uiRl67DSleyaCwF53s4PA  
爱的定义  
https://pan.baidu.com/s/1UZFq5G3MozpErZbRfVsveQ  
诱爱入局  
https://pan.baidu.com/s/1FY1YB0P67PlK9xUZw3guSA  
毕业阵痛记  
https://pan.baidu.com/s/18EVd2Dks8GNBvGG8_VuIhw  
### 日剧👇

毛骨悚然撞鬼经-2020秋季特别篇  
https://pan.baidu.com/s/1J4VIntd9pJ4dcmCRyqe5Ew  
消除老师的方程式  
https://pan.baidu.com/s/1-HvPHyd-xsn35QpRqJNMKw  
一亿日元的告别  
https://pan.baidu.com/s/1V8a2Qs1klxzed0GaUB8r6w  
姐姐的恋人  
https://pan.baidu.com/s/1Y-9gIuJkyZ2rwqHuNvZZmA  
单恋美食家日记  
https://pan.baidu.com/s/10gREEmgIS9CjdoxVHnvq7Q  
### 广播剧👇

图灵密码第二季（02）  
https://pan.baidu.com/s/1kI05dKhq9MAbXh8-OIz6Mg  
解药（08）  
https://pan.baidu.com/s/1AQ53wmwye9AWSbBkTvwzwQ  
补全球高考第一季.下载后解压否则和谐打不开  
https://pan.baidu.com/s/1zG7UCaZm2R1CTxgRT-CA3Q  
窥光（06）  
https://pan.baidu.com/s/1v0M3BkKdg-kOiLlHPfezGA  
LASER出道日（金猫奖提名）  
https://pan.baidu.com/s/1UoO44oOC_4DNocFriXrD6g  
08321（01）  
https://pan.baidu.com/s/1oUvnCh9WyTDcHeLU40vVUQ  
大力出奇迹（04上）  
https://pan.baidu.com/s/1ISC_fbS94rtqiufVRa3USg  
请你将就一下（02）  
https://pan.baidu.com/s/1R0vg1onSKEWx_BijpcgaIw  
DOLO命运胶囊（06）  
https://pan.baidu.com/s/1z4I6UH11y5twjwlZbnHH5w  
哪里来的大宝贝（15）  
https://pan.baidu.com/s/12Eqb3WkFAxAhOpmsUIy5_g  
论如何与419对象和平分手（01）  
https://pan.baidu.com/s/19UvqsAfe9zVI6uCBIFjVNQ  
三国演义（03）  
https://pan.baidu.com/s/1scbPUu0THYEYnWzwH7sscw  
SCI谜案集第三季（13花絮）  
https://pan.baidu.com/s/18gcydZUemitKsyoiJJNHtA  
将进酒第二季（花絮4）  
https://pan.baidu.com/s/1fh1aeAN4uKUbzHYJ92C2JA  
假凤虚凰（07）  
https://pan.baidu.com/s/1AJLjLVakmsPbGOsfZgpnEA  
云绪（01）  
https://pan.baidu.com/s/1YEzG-y8SYkoDlU6vaBe5Xw  
异国留学遇见前男友怎么办（01ED）  
https://pan.baidu.com/s/1vgHK7aF0K8TkJXHolQ_dRw  
你的目光所及之处 中文翻配（01）  
https://pan.baidu.com/s/1t0O4__kVu0CWllvFu7PGUA  
兼职无常后我红了（29）  
https://pan.baidu.com/s/1bRAuzLFuSS_Ch_63Kl1qbQ  
这题超纲了（58）  
https://pan.baidu.com/s/1z4KrcPswWi83nHbGa5W57Q  
我有一段情  
https://pan.baidu.com/s/1uQH9b8j-KptXALOFdy-30Q  
我的同学神烦（04）  
https://pan.baidu.com/s/1twpehS45z3p5DWNV0V55Cw  
5个全一期  
https://pan.baidu.com/s/1d-3FzKElQ6tZZuOBZJGJdQ  
战疫2020之我是医生  
https://pan.baidu.com/s/1GEl8o6HOkHX1EWnDJAYQWw  

### 小说【11.04】

https://pan.baidu.com/s/1wbOTqTntoSGamN8et0Sf1w  
https://pan.baidu.com/s/10Ymi54yQaPLTNMqeKNiIZQ    